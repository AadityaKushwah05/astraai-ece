# AstraAI Android starter — cloud build

This repository layout is prepared for GitHub Actions to attempt a debug APK build.

## What this is
- Android source project with AstraAI navy-and-gold styling and splash artwork.
- GitHub Actions workflow at `.github/workflows/android-apk.yml` builds a debug APK when pushed to `main`, or when manually run.

## Build using GitHub Actions
1. Create/open a GitHub repository.
2. Upload the **contents of this folder** to the repository root (so `settings.gradle.kts`, `app/`, and `.github/` are directly at the repository root, not nested inside another folder).
3. Open the repository's **Actions** tab and select **Build AstraAI APK**. If prompted, enable Actions; then choose **Run workflow**.
4. When the run succeeds, open the run and download the `AstraAI-debug-apk` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Feature status — please read
This is a starter/mockup, not a complete release-ready app. It currently contains the splash/home UI and placeholder feature screens. Working AI responses, accounts, Google sign-in, saved chats, real virtual lab simulations, a coding editor/runtime, and a secure AI backend have not been implemented. Do not distribute it as a complete AI assistant. A debug APK may require allowing installation from the source used to download it.

Online AI requires a backend/API connection. Never put a private provider API key directly inside a public APK.
