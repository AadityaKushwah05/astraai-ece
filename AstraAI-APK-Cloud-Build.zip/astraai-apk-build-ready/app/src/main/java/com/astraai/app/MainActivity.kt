package com.astraai.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(8, 15, 32)
    private val panel = Color.rgb(19, 30, 51)
    private val gold = Color.rgb(232, 196, 106)
    private lateinit var root: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showSplash() }
    private fun base(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(navy); setPadding(20,18,20,18) }
    private fun text(s:String, size:Float, color:Int=Color.WHITE, bold:Boolean=false): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER_VERTICAL }
    private fun button(s:String, action:()->Unit): Button = Button(this).apply { text=s; setTextColor(navy); setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold)); setOnClickListener { action() } }
    private fun showSplash() {
        root=base(); root.gravity=Gravity.CENTER
        val image=ImageView(this).apply { setImageResource(com.astraai.app.R.drawable.astraai_splash); scaleType=ImageView.ScaleType.CENTER_CROP; contentDescription="AstraAI premium opening screen" }
        root.addView(image, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(button("GET STARTED  →") { showHome() }, LinearLayout.LayoutParams(-1,58))
        setContentView(root)
    }
    private fun showHome() {
        root=base(); root.addView(text("AstraAI",30f,gold,true)); root.addView(text("Ancient Wisdom × Modern AI",15f,Color.LTGRAY)); root.addView(text("सर्वे भवन्तु सुखिनः",18f,gold,true))
        val scroll=ScrollView(this); val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,20,0,0) }
        val sections=listOf("AI Chat" to "Ask questions and explore ideas", "Virtual Labs" to "Explore science and engineering experiments", "Coding Studio" to "Write, learn, and debug code", "Study & Research" to "Learn concepts and organize research", "Engineering Tools" to "Technical calculations and utilities", "Spiritual Growth" to "Wisdom, Sanskrit, and reflection")
        sections.forEach { (title,desc) ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,12,18,12); setBackgroundColor(panel) }
            card.addView(text(title,19f,gold,true)); card.addView(text(desc,14f,Color.LTGRAY))
            val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; list.addView(card,lp)
            card.setOnClickListener { showSection(title) }
        }
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun showSection(title:String) {
        root=base(); root.addView(text("‹  $title",26f,gold,true)); root.addView(text("AstraAI • Ancient Wisdom × Modern AI",13f,Color.LTGRAY))
        val note=when(title){
            "AI Chat" -> "AI chat needs an AI provider endpoint and API key. Add secure backend configuration before using online AI."
            "Virtual Labs" -> "Choose and open official Virtual Labs experiments. Interactive simulations must be linked or implemented individually."
            "Coding Studio" -> "Language picker and editor are planned. Running code requires a secure execution engine; do not execute untrusted code directly on a server."
            "Study & Research" -> "Study notes, explanations, and research tools can be added here."
            "Engineering Tools" -> "Engineering calculators and practical utilities can be added here."
            else -> "Sanskrit verses, reflection, and spiritual learning can be added here."
        }
        root.addView(text(note,17f,Color.WHITE)); root.addView(button("BACK TO HOME") { showHome() })
        setContentView(root)
    }
}
